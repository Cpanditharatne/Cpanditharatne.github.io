tinyMCE.addI18n('fr_FR', {
	'localautosave.restoreContent' : 'Restaurer le contenu',
	'localautosave.chooseVersion' : 'Choisissez ce que vous voulez restaurer',
	'localautosave.chars' : 'caractères',
	'localautosave.clearAll' : 'Supprimer toutes les versions enregistrées',
	'localautosave.noContent' : 'Il n\'y a pas de contenu disponible à restaurer.',
	'localautosave.ifRestore' : 'Si vous restaurez le contenu sauvegardé, vous perdrez tout le contenu qui est en cours d\'édition.\n\nEtes-vous sûr de vouloir restaurer le contenu sauvegardé ?'
});
