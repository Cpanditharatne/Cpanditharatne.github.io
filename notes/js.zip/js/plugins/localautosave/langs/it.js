tinyMCE.addI18n('it.localautosave', {
	'localautosave.restoreContent' : 'Ripristina il contenuto',
	'localautosave.chooseVersion' : 'Scegli tra le versioni disponibili',
	'localautosave.chars' : 'caratteri',
	'localautosave.clearAll' : 'Scarta tutte le versioni',
	'localautosave.noContent' : 'Non ci sono versioni recuperabili per questo testo',
	'localautosave.ifRestore' : 'Attenzione: sostituire il testo con quello precedentemente salvato?'
});
