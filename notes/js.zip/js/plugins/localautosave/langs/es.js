tinyMCE.addI18n('es.localautosave', {
	'localautosave.restoreContent' : 'Restaurar Contenido',
	'localautosave.chooseVersion' : 'Elije la versión que deseas restaurar',
	'localautosave.chars' : 'caracteres',
	'localautosave.clearAll' : 'Desechar todas las versiones guardadas',
	'localautosave.noContent' : 'No existe contenido disponible para restaurar.',
	'localautosave.ifRestore' : 'Si restauras el contenido guardado, perderás todo el contenido existente en el editor \n\nEstás seguro de restaurar el contenido?'
});
